package pages;

import wrappers.LeafTapsWrappers;

public class Home extends LeafTapsWrappers{
	
	public Home(){
		if(!verifyTitle("System Administration | ServiceNow")){
			reportStep("This is NOT Home Page", "FAIL");
		}
	}
	
	
	public Login clickLogout(){
		clickByClassName("decorativeSubmit");
		return new Login();
	}
	
	public void clickCRMSFA(){
		clickByLink("CRM/SFA");
	}
	
	
	
	
	
	
	
	
	
	

}
